fx_version 'cerulean'
game 'gta5'
author 'Indru'
description 'Give car to a player'
version '1.0.0'

server_script 'server.lua'

dependency 'oxmysql'